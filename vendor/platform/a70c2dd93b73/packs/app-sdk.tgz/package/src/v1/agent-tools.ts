/**
 * Manifest `contributes.agentTools`（Host API 1.26）：插件显式声明给 Agent 用的工具。
 *
 * 每项必须且只能声明一种来源：
 * - `command`：本包 `contributes.commands` 里 `callers` 含 `"app"` 的命令；
 * - `service` + `method`：本包 `contributes.services` 的方法，且包声明 `apps.service@1`；
 * - `builtin`：Host 内置工具的声明绑定（支持矩阵 `builtinBindings` 的键），`id` 必须与之相同，
 *   且包声明该工具对应的 Host 能力。
 *
 * command/service 投影为 `app.<appId>.<id>`；builtin 对外名不变。声明不等于授权：
 * Host 仍按能力 grant、用户同意与会话权限决定能否调用。
 */

interface AgentToolContributionBase {
  /** 包内唯一，`^[a-z][a-z0-9_-]*$`，最长 48 个字符。 */
  id: string;
  /** 给模型看的工具说明，1..=1024 个字符。 */
  description?: string;
}

/** 由本包命令实现的 Agent 工具。 */
export interface AgentToolCommandContribution extends AgentToolContributionBase {
  command: string;
  service?: never;
  method?: never;
  builtin?: never;
}

/** 由本包 Service 方法实现的 Agent 工具。 */
export interface AgentToolServiceContribution extends AgentToolContributionBase {
  service: string;
  method: string;
  command?: never;
  builtin?: never;
}

/** Host 内置工具的声明绑定。 */
export interface AgentToolBuiltinContribution extends AgentToolContributionBase {
  builtin: string;
  command?: never;
  service?: never;
  method?: never;
}

/** `contributes.agentTools` 的一项。 */
export type AgentToolContribution =
  | AgentToolCommandContribution
  | AgentToolServiceContribution
  | AgentToolBuiltinContribution;

/** Manifest `contributes` 中与 Agent 工具相关的片段。 */
export interface AgentToolsContributes {
  agentTools?: AgentToolContribution[];
}
