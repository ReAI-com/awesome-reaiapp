# Wainao Developer Platform v1.0

`v1.ts` defines the frozen Developer Platform contract v1.0 (an exact copy of the backend contract).
Fixture: `platform/sdk/tests/fixtures/developer-platform-v1.json`.

These DTOs do not add Bridge methods or assert deployment. SDK/Host methods must
be wired explicitly and continue enforcing official plugin, scope and actor gates.
Delist preserves the real public revision pointer. Recovery requires both release
status and the selected client's current pointer; pointer equality alone is not a
successful re-publish.
