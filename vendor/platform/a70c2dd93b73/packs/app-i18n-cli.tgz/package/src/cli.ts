#!/usr/bin/env bun
import { buildApp, packApp, parseCompression, validateManifestFile, readSourceReviewEvidence } from "./index";
import { join, resolve } from "node:path";
import { BuildError, type Finding } from "@reai/app-cli";
import { sideloadHintCapabilities } from "./source-approval";
import { readFileSync } from "node:fs";
import { runSubmissionCli } from "./submission";
import { runReviewBytesCli } from "./review-bytes-cli";
const usage="reai-app-i18n validate <appDir> | build <appDir> | pack <appDir> --out <package.reaiapp> [--source-review <evidence.json> [--review-root <dir>]] [--compression store|deflate] [--local-dev] | submission check|pack <appDir> … | review-bytes <appDir> --inputs <pin.json> --out <newDir> --expected-bun <version> …";
/** Review-root mode: the private root never appears in output (success paths or error messages). */
let privateRoot:string|undefined;
const shown=(text:string)=>privateRoot?text.replaceAll(privateRoot,"<review-root>"):text;
async function main(){
  const [command,directory,...rawArgs]=process.argv.slice(2);
  // --local-dev：按侧载（开发者模式本地安装）口径校验，白名单内能力与商店同权（issue #1444）。
  const localDev=rawArgs.includes("--local-dev"),args=rawArgs.filter(arg=>arg!=="--local-dev");
  if(command==="--help"||command==="-h"){console.log(usage);return;}
  // Submission and review-byte entries keep their own strict argument parsers and redacted output.
  if(command==="submission"){process.exitCode=await runSubmissionCli(process.argv.slice(3));return;}
  if(command==="review-bytes"){process.exitCode=await runReviewBytesCli(process.argv.slice(3));return;}
  if(command==="--version"){console.log(JSON.parse(readFileSync(new URL("../package.json",import.meta.url),"utf8")).version);return;}
  if(!directory)throw new Error(usage);
  const options=new Map<string,string>();
  if(args.length%2)throw new Error(usage);
  for(let at=0;at<args.length;at+=2){
    const key=args[at]!,value=args[at+1]!;
    if(!["--source-review","--review-root",...(command==="pack"?["--out","--compression"]:[])].includes(key)||!value||value.startsWith("--")||options.has(key))throw new Error(usage);
    options.set(key,value);
  }
  const compression=parseCompression(options.get("--compression")),reviewPath=options.get("--source-review");
  const reviewRoot=options.get("--review-root");
  if(reviewRoot&&!reviewPath)throw new Error(usage);
  if(reviewRoot)privateRoot=resolve(reviewRoot);
  const sourceReview=reviewPath?readSourceReviewEvidence(reviewPath,{reviewRoot}):undefined;
  if(sourceReview)console.log("Source review evidence: local submission preflight only; no Host runtime authorization");
  if(command==="validate"){
    const findings=validateManifestFile(join(resolve(directory),"app.manifest.json"),true,sourceReview,localDev);
    if(findings.length)throw new BuildError("Plugin language validation failed",findings);
    console.log("✓ Manifest, language resources and metadata references validated");
  }else if(command==="build"){
    await buildApp(directory,true,sourceReview,localDev);console.log("✓ Built with language validation");
  }else if(command==="pack"){
    const output=options.get("--out");
    if(!output)throw new Error(usage);
    const result=await packApp(directory,output,true,sourceReview,{compression,localDev});console.log(shown(`✓ ${result.outputPath}\nSHA-256 ${result.archiveDigest}`));
  }else throw new Error(usage);
}
main().catch(error=>{
  console.error(shown(error instanceof Error?error.message:String(error)));
  if(error instanceof BuildError){
    for(const f of error.findings)console.error(shown(`[${f.code}] ${f.pointer}: ${f.detail}`));
    sideloadHint(error.findings);
  }
  process.exitCode=1;
});
/**
 * 默认（商店）口径拦下白名单内能力时，提示本地开发安装可加 --local-dev（issue #1444）。
 * 只在交互终端里打印：受控发布等脚本逐行比对 stderr，非终端输出必须保持原样。
 */
function sideloadHint(findings: readonly Finding[]){
  const [command,directory,...rawArgs]=process.argv.slice(2);
  if(!process.stderr.isTTY||rawArgs.includes("--local-dev")||!directory||!["validate","build","pack"].includes(command??""))return;
  try{
    const manifest=JSON.parse(readFileSync(join(resolve(directory),"app.manifest.json"),"utf8"));
    const capabilities=sideloadHintCapabilities(manifest,[...findings]);
    if(capabilities.length)console.error(`提示：${capabilities.join("、")} 在开发者模式本地安装时与商店同权，本地开发安装可加 --local-dev 打包；上架商店仍需平台审核。`);
  }catch{/* 读不到 Manifest 时不提示 */}
}
