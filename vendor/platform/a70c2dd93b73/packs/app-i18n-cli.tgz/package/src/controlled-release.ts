/**
 * Controlled plugins (those whose gated capabilities need a per-version source review) take two paths:
 *
 * 1. Public CI computes only the unapproved review bytes (`review-bytes`) and checks that validate / build / pack are
 *    rejected by the approval gate and by nothing else (`runPendingApprovalGate`).
 * 2. A private review inside an explicit review root approves that exact commit and those bytes; the normal pack
 *    reproduces them (`--source-review … --review-root …`), and `createControlledReleaseRequest` emits a digest-only
 *    request that the plugin repository's controlled release entry checks with `verifyControlledReleaseRequest`.
 *
 * Every function here is a consistency check only; the release entry must also authenticate where a request came from. None grants approval, a runtime grant or platform review;
 * the Host still authorizes installation from the review receipt and package digest.
 */
import { createHash } from "node:crypto";
import { mkdtempSync, readFileSync, readdirSync, realpathSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { spawnSync } from "node:child_process";
import { APP_MANIFEST_NAME } from "@reai/app-cli";
import { readPackageZip } from "./archive";
import { sourceApprovalFindings } from "./source-approval";
import { collectSourceReviewInputs, readRootedSourceReviewEvidence, sourceReviewEvidenceFindings, sourceReviewInputsDigest, sourceReviewRoot } from "./source-review-evidence";

const sha = (bytes: Uint8Array | string) => createHash("sha256").update(bytes).digest("hex");
const DIGEST = /^[a-f0-9]{64}$/, COMMIT = /^[a-f0-9]{40}$/;
const REPOSITORY = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})\/[A-Za-z0-9._-]{1,100}$/;

export type PendingStep = "validate" | "build" | "pack";
/** First stderr line the normal CLI prints for a rejected step (see cli.ts / build.ts / index.ts preflight). */
const STEP_HEADER: Record<PendingStep, string> = {
  validate: "Plugin language validation failed",
  build: "Manifest 校验未通过，构建中止",
  pack: "Plugin language validation failed",
};

type Manifest = Parameters<typeof sourceApprovalFindings>[0];
/** The exact approval denials an unreviewed version must produce: one per gated, unapproved declaration. */
export function expectedApprovalDenials(manifest: Manifest): string[] {
  return sourceApprovalFindings(manifest, [])
    .filter(finding => finding.code === "APP_CAPABILITY_NOT_GRANTED")
    .map(finding => `[${finding.code}] ${finding.pointer}: ${finding.detail}`);
}

export interface PendingJudgement { step: PendingStep; ok: boolean; reason?: string }

/**
 * Accepts only "rejected by the approval gate, and by nothing else": exit 1, empty stdout, the step's header and
 * exactly the expected denial lines (no extra, no missing, no duplicate). Validate stops at Manifest findings, so a
 * locale error can hide behind denials there; build reports both, which is why the gate always runs all three steps.
 */
export function judgePendingApprovalRun(step: PendingStep, run: { exitCode: number | null; stdout: string; stderr: string }, manifest: Manifest): PendingJudgement {
  const no = (reason: string): PendingJudgement => ({ step, ok: false, reason });
  const expected = expectedApprovalDenials(manifest);
  if (expected.length === 0) return no("plugin needs no source review; pack it directly instead of the controlled path");
  if (run.exitCode !== 1) return no(`expected exit 1, got ${run.exitCode}`);
  if (run.stdout.trim() !== "") return no("unexpected stdout");
  const lines = run.stderr.split(/\r?\n/).filter(line => line.trim() !== "");
  if (lines[0] !== STEP_HEADER[step]) return no("unexpected failure header");
  const findings = lines.slice(1);
  if (new Set(findings).size !== findings.length) return no("duplicate finding");
  const unexpected = findings.filter(line => !expected.includes(line));
  if (unexpected.length) return no(`unexpected finding: ${unexpected[0]!.replace(/^\[([A-Z_]+)\] ([^:]+):.*$/, "$1 at $2")}`);
  if (findings.length !== expected.length) return no("expected approval denial missing");
  return { step, ok: true };
}

/** The normal CLI as installed for the plugin (same entry an ordinary `reai-app-i18n` call would run). */
function installedCli(appDirectory: string): string {
  return join(dirname(realpathSync(Bun.resolveSync("@reai/app-i18n-cli", appDirectory))), "cli.ts");
}

/**
 * Runs validate / build / pack through the installed CLI and judges each step. Pack writes to a fresh directory
 * outside the plugin and must produce nothing; the complete source input inventory must not change.
 */
export function runPendingApprovalGate(appDirectory: string, options: { cli?: string } = {}): { ok: boolean; steps: PendingJudgement[] } {
  const root = realpathSync(resolve(appDirectory));
  const manifest = JSON.parse(readFileSync(join(root, APP_MANIFEST_NAME), "utf8")) as Manifest;
  const cli = options.cli ?? installedCli(root);
  const before = sourceReviewInputsDigest(collectSourceReviewInputs(root));
  const out = realpathSync(mkdtempSync(join(tmpdir(), "reai-pending-gate-")));
  try {
    // Outside = a parent-relative path, or (Windows, another drive) an absolute one.
    const rel = relative(root, out);
    if (!(isAbsolute(rel) || rel === ".." || rel.startsWith(`..${sep}`) || rel.startsWith("../"))) throw new Error("Pending gate output must be outside the plugin");
    const steps = (["validate", "build", "pack"] as const).map(step => {
      const args = [cli, step, root, ...(step === "pack" ? ["--out", join(out, "pending.reaiapp")] : [])];
      const result = spawnSync(process.execPath, args, { cwd: root, encoding: "utf8" });
      return judgePendingApprovalRun(step, { exitCode: result.status, stdout: result.stdout ?? "", stderr: result.stderr ?? "" }, manifest);
    });
    if (readdirSync(out).length) steps.push({ step: "pack", ok: false, reason: "rejected pack produced output" });
    if (sourceReviewInputsDigest(collectSourceReviewInputs(root)) !== before) steps.push({ step: "pack", ok: false, reason: "source inputs changed during the gate" });
    return { ok: steps.every(step => step.ok), steps };
  } finally { rmSync(out, { recursive: true, force: true }); }
}

export interface ControlledReleaseRequest {
  schemaVersion: 1;
  purpose: "controlled-plugin-release";
  appId: string;
  version: string;
  sourceRepository: string;
  sourceCommit: string;
  packageSha256: string;
  reviewInputsSha256: string;
  toolchainReceiptSha256: string;
  /** Recorded only: the public side cannot (and must not) read the private evidence. */
  evidenceSha256: string;
}
const REQUEST_KEYS = ["schemaVersion", "purpose", "appId", "version", "sourceRepository", "sourceCommit", "packageSha256", "reviewInputsSha256", "toolchainReceiptSha256", "evidenceSha256"];

/** Canonical digest of a complete request (fixed key order); what the trusted channel authorizes. */
export function controlledReleaseRequestDigest(request: ControlledReleaseRequest): string {
  return sha(JSON.stringify(Object.fromEntries(REQUEST_KEYS.map(key => [key, (request as unknown as Record<string, unknown>)[key]]))));
}

function packagedIdentity(bytes: Buffer): { appId: unknown; version: unknown } {
  const manifest = readPackageZip(bytes).get(APP_MANIFEST_NAME);
  if (!manifest) throw new Error("Package has no app manifest");
  const parsed = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(manifest));
  return { appId: parsed.appId, version: parsed.version };
}

/** Private side: re-verifies v2 evidence in its review root and the final package, then emits digests only. */
export function createControlledReleaseRequest(input: { appDirectory: string; evidencePath: string; reviewRoot: string; packagePath: string }): ControlledReleaseRequest {
  // One read: the request's fields and its evidence digest come from the same verified bytes.
  const { evidence, bytes: evidenceBytes } = readRootedSourceReviewEvidence(input.evidencePath, input.reviewRoot);
  if (evidence.schemaVersion !== 2 || !evidence.binding || sourceReviewRoot(evidence) === undefined) throw new Error("Controlled release needs v2 evidence with an explicit review root");
  const root = realpathSync(resolve(input.appDirectory));
  const manifest = JSON.parse(readFileSync(join(root, APP_MANIFEST_NAME), "utf8")) as Record<string, unknown>;
  const findings = sourceReviewEvidenceFindings(manifest, evidence, root);
  if (findings.length) throw new Error(`Source review evidence rejected: ${findings[0]!.detail}`);
  const bytes = readFileSync(input.packagePath);
  if (sha(bytes) !== evidence.expectedPackageSha256) throw new Error("Package digest differs from the reviewed package");
  const packaged = packagedIdentity(bytes);
  if (packaged.appId !== evidence.appId || packaged.version !== evidence.version) throw new Error("Package identity differs from the reviewed identity");
  const { binding } = evidence;
  return { schemaVersion: 1, purpose: "controlled-plugin-release", appId: evidence.appId, version: evidence.version,
    sourceRepository: binding.sourceRepository, sourceCommit: binding.sourceCommit, packageSha256: evidence.expectedPackageSha256,
    reviewInputsSha256: binding.reviewInputs.sha256, toolchainReceiptSha256: binding.toolchainReceiptSha256,
    evidenceSha256: sha(evidenceBytes) };
}

/**
 * Public side (controlled release entry): `repository` / `commit` come from the CI environment, `reviewInputsBytes`
 * is the calculation this repository produced for that commit (taken from the same job's artifact, not recomputed
 * on another machine). Every request field can be computed from public material, so self-consistency alone does not
 * prove a private review happened: `authorizedRequestSha256` must come from a trusted channel the release entry owns
 * (a protected private trigger or a pre-registered record) and must equal `controlledReleaseRequestDigest(request)`,
 * which binds every field (repository, commit, package, review input, receipt and evidence digests) at once.
 * Throws on any mismatch.
 */
export function verifyControlledReleaseRequest(request: unknown, context: { repository: string; commit: string; packageBytes: Buffer; reviewInputsBytes: Buffer; authorizedRequestSha256: string }): ControlledReleaseRequest {
  const r = request as ControlledReleaseRequest;
  if (!r || typeof r !== "object" || Array.isArray(r) || JSON.stringify(Object.keys(r).sort()) !== JSON.stringify([...REQUEST_KEYS].sort())
    || r.schemaVersion !== 1 || r.purpose !== "controlled-plugin-release" || typeof r.appId !== "string" || !r.appId || typeof r.version !== "string" || !r.version
    || typeof r.sourceRepository !== "string" || !REPOSITORY.test(r.sourceRepository) || typeof r.sourceCommit !== "string" || !COMMIT.test(r.sourceCommit)
    || [r.packageSha256, r.reviewInputsSha256, r.toolchainReceiptSha256, r.evidenceSha256].some(value => typeof value !== "string" || !DIGEST.test(value))) throw new Error("Controlled release request is malformed");
  if (typeof context.authorizedRequestSha256 !== "string" || !DIGEST.test(context.authorizedRequestSha256)
    || controlledReleaseRequestDigest(r) !== context.authorizedRequestSha256) throw new Error("Controlled release request is not authorized");
  if (r.sourceRepository !== context.repository) throw new Error("Controlled release repository differs");
  if (r.sourceCommit !== context.commit) throw new Error("Controlled release commit differs");
  if (sha(context.packageBytes) !== r.packageSha256) throw new Error("Controlled release package differs");
  if (sha(context.reviewInputsBytes) !== r.reviewInputsSha256) throw new Error("Controlled release review input differs");
  const calculation = JSON.parse(context.reviewInputsBytes.toString("utf8"));
  const source = calculation?.toolchain?.toolchainSource;
  if (calculation?.purpose !== "unapproved-source-review-bytes" || calculation.archiveSha256 !== r.packageSha256
    || calculation.toolchain.gitHead !== r.sourceCommit || source?.kind !== "receipt-content-consistent"
    || source.receiptSha256 !== r.toolchainReceiptSha256) throw new Error("Controlled release request differs from the public review input");
  if (calculation.identity?.appId !== r.appId || calculation.identity?.version !== r.version) throw new Error("Controlled release identity differs from the public review input");
  const packaged = packagedIdentity(context.packageBytes);
  if (packaged.appId !== r.appId || packaged.version !== r.version) throw new Error("Controlled release package identity differs");
  return r;
}
