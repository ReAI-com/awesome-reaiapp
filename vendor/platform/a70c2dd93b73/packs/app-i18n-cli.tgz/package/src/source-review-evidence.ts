/** Explicit local submission preflight evidence. Never runtime or platform authorization. */
import { createHash } from "node:crypto";
import { existsSync, lstatSync, readFileSync, readdirSync, realpathSync } from "node:fs";
import { spawnSync } from "node:child_process";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import type { Finding } from "@reai/app-cli";
import { assertSafeTree, isSafePackagePath, safeChild } from "./paths";

/**
 * v2 only (explicit review root): the private review is bound to the public plugin repository, the exact commit,
 * the complete public review input (the unapproved review-byte calculation), the platform toolchain receipt and,
 * through `expectedPackageSha256`, the final package.
 */
export interface SourceReviewBinding {
  sourceRepository: string;
  sourceCommit: string;
  reviewInputs: { path: string; sha256: string };
  toolchainReceiptSha256: string;
}

export interface SourceReviewEvidence {
  schemaVersion: 1 | 2;
  purpose: "submission-source-review";
  appId: string;
  publisherId: string;
  oauthAppId: string;
  version: string;
  reviewedHostCapabilities: string[];
  sourceFiles: Record<string, string>;
  reviewReports: { path: string; sha256: string }[];
  expectedPackageSha256: string;
  binding?: SourceReviewBinding;
}

/**
 * The explicit review root lives only on the in-memory evidence object, under a private Symbol: an evidence file
 * cannot choose its own root (JSON has no Symbols), and receipts / logs that serialize the evidence never carry
 * the absolute path. Object spread keeps it; structuredClone drops it, which fails closed (v2 needs a root).
 */
const REVIEW_ROOT = Symbol("reai.sourceReviewRoot");
type Rooted = SourceReviewEvidence & { [REVIEW_ROOT]?: string };
export const sourceReviewRoot = (evidence: SourceReviewEvidence): string | undefined => (evidence as Rooted)[REVIEW_ROOT];

/** Physical, existing, non-symlink directory (also rejects symlink ancestors: realpath must equal the path). */
function physicalReviewRoot(path: string): string {
  const root = resolve(path);
  let physical: string;
  try { physical = realpathSync(root); } catch { throw new Error("Review root does not exist"); }
  if (physical !== root) throw new Error("Review root contains a symlink. Use the physical path from realpath.");
  if (!lstatSync(root).isDirectory()) throw new Error("Review root is not a directory");
  return root;
}

/**
 * Review-root mode only (the default mode keeps its messages): native fs errors embed absolute paths, so they become
 * fixed messages; JSON errors become a fixed message; any remaining occurrence of the root is replaced.
 */
export function reviewRootError(cause: unknown, root: string): string {
  const code = (cause as NodeJS.ErrnoException | undefined)?.code;
  if (typeof code === "string" && /^E[A-Z]+$/.test(code)) return `Review root file is missing or unreadable (${code})`;
  if (cause instanceof SyntaxError) return "Review root file is not valid JSON";
  return (cause instanceof Error ? cause.message : "Invalid source review evidence").replaceAll(root, "<review-root>");
}

/** Attach an explicit independent review root to evidence read or built in-process. */
export function bindSourceReviewRoot<T extends SourceReviewEvidence>(evidence: T, reviewRoot: string): T {
  if (Object.hasOwn(evidence, REVIEW_ROOT)) throw new Error("Source review evidence already has a review root");
  Object.defineProperty(evidence, REVIEW_ROOT, { value: physicalReviewRoot(reviewRoot), enumerable: true, configurable: false, writable: false });
  return evidence;
}

const digest = (bytes: string | Uint8Array) => createHash("sha256").update(bytes).digest("hex");
const validDigest = (value: unknown): value is string => typeof value === "string" && /^[a-f0-9]{64}$/.test(value);
const orderedFiles = (files: Record<string, string>) => Object.fromEntries(Object.entries(files).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0));
export const sourceReviewInputsDigest = (files: Record<string, string>): string => digest(JSON.stringify(orderedFiles(files)));

/** Conservative complete input inventory, including local packages/config/assets/locks.
 * Root build outputs and dependency installs are excluded; package digest binds output. */
export function collectSourceReviewInputs(appDirectory: string): Record<string, string> {
  const root = resolve(appDirectory);
  if (lstatSync(root).isSymbolicLink()) throw new Error("Source review app root is a symlink");
  const files: Record<string, string> = {};
  const visit = (directory: string, prefix = "") => {
    for (const name of readdirSync(directory).sort()) {
      const path = prefix ? `${prefix}/${name}` : name;
      if (name === "node_modules" || name === ".git" || (!prefix && (name === "dist" || name === "build-manifest.json" || name.endsWith(".reaiapp")))) continue;
      if (!isSafePackagePath(path)) throw new Error("Unsafe source review input path");
      const full = safeChild(root, path), stat = lstatSync(full);
      if (stat.isSymbolicLink()) throw new Error(`Source review input is a symlink: ${path}`);
      if (stat.isDirectory()) visit(full, path);
      else if (stat.isFile()) files[path] = digest(readFileSync(full));
      else throw new Error(`Unsupported source review input: ${path}`);
    }
  };
  visit(root);
  return orderedFiles(files);
}

function repositoryRoot(appDirectory: string): string {
  const root = resolve(appDirectory);
  let candidate = root;
  for (;;) {
    if (existsSync(join(candidate, ".git"))) return candidate;
    const parent = dirname(candidate);
    if (parent === candidate) return root;
    candidate = parent;
  }
}
/** A file inside `root` under the same escape / symlink / regular-file rules as review reports. */
function rootedFile(root: string, path: string, label: string, rootLabel: string): string {
  const full = isAbsolute(path) ? resolve(path) : safeChild(root, path);
  const rel = relative(root, full).replaceAll("\\", "/");
  if (!isSafePackagePath(rel)) throw new Error(`${label} escapes ${rootLabel}`);
  assertSafeTree(root, rel);
  if (!lstatSync(full).isFile()) throw new Error(`${label} is not a regular file`);
  return full;
}
function reportPath(appDirectory: string, path: string, reviewRoot?: string): string {
  return reviewRoot ? rootedFile(reviewRoot, path, "Review report", "review root")
    : rootedFile(repositoryRoot(appDirectory), path, "Review report", "repository root");
}
/** Review-root read that also returns the exact bytes it parsed, so callers can digest the same evidence they verify. */
export function readRootedSourceReviewEvidence(path: string, reviewRoot: string): { evidence: SourceReviewEvidence; bytes: Buffer } {
  const root = physicalReviewRoot(reviewRoot);
  try {
    const bytes = readFileSync(rootedFile(root, resolve(path), "Source review evidence", "review root"));
    return { evidence: bindSourceReviewRoot(JSON.parse(bytes.toString("utf8")) as SourceReviewEvidence, root), bytes };
  } catch (cause) { throw new Error(reviewRootError(cause, root)); }
}
export function readSourceReviewEvidence(path: string, options: { reviewRoot?: string | undefined } = {}): SourceReviewEvidence {
  const full = resolve(path);
  if (options.reviewRoot !== undefined) return readRootedSourceReviewEvidence(full, options.reviewRoot).evidence;
  // The explicit evidence artifact itself cannot alias another file through a symlink.
  let prefix = dirname(full);
  while (dirname(prefix) !== prefix) {
    if (lstatSync(prefix).isSymbolicLink()) throw new Error("Source review evidence path is a symlink");
    prefix = dirname(prefix);
  }
  if (!lstatSync(full).isFile() || lstatSync(full).isSymbolicLink()) throw new Error("Source review evidence is not a regular file");
  return JSON.parse(readFileSync(full, "utf8")) as SourceReviewEvidence;
}

const REPOSITORY = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})\/[A-Za-z0-9._-]{1,100}$/;
const COMMIT = /^[a-f0-9]{40}$/;
const exactKeys = (value: unknown, keys: string[]) => !!value && typeof value === "object" && !Array.isArray(value)
  && JSON.stringify(Object.keys(value).sort()) === JSON.stringify([...keys].sort());
const git = (cwd: string, args: string[]) => {
  const result = spawnSync("git", args, { cwd, encoding: "utf8" });
  if (result.status !== 0) throw new Error("Plugin source Git identity unavailable");
  return result.stdout;
};

/**
 * Every collected source input (ignored-but-collected files included) must be that exact file of the commit.
 * Compared as Git object IDs: the commit's tree entries under the plugin directory versus `hash-object` of the
 * working file, which applies the same clean filters (eol, attributes) the commit went through.
 */
function assertInputsAreCommitted(app: string, commit: string, inputs: Record<string, string>): void {
  // Git trees record precomposed (NFC) names while macOS may list decomposed (NFD) ones: compare normalized names.
  const tree = new Map<string, string>();
  for (const record of git(app, ["ls-tree", "-r", "-z", commit]).split("\0")) {
    if (!record) continue;
    const tab = record.indexOf("\t"), [, type, oid] = record.slice(0, tab).split(" ");
    const name = record.slice(tab + 1).normalize("NFC");
    if (tree.has(name)) throw new Error("Reviewed commit has ambiguous file names");
    if (type === "blob" && oid) tree.set(name, oid);
  }
  const paths = Object.keys(inputs);
  if (new Set(paths.map(path => path.normalize("NFC"))).size !== paths.length) throw new Error("Source review inputs have ambiguous file names");
  if (paths.some(path => !tree.has(path.normalize("NFC")))) throw new Error("Source review input is not part of the reviewed commit");
  // --stdin-paths resolves against the repository top level; pass prefix-relative names (inputs never contain control characters).
  const prefix = git(app, ["rev-parse", "--show-prefix"]).replace(/\n$/, "");
  if (/[\u0000-\u001f\u007f]/.test(prefix)) throw new Error("Plugin directory name is not supported for commit binding");
  const top = git(app, ["rev-parse", "--show-toplevel"]).replace(/\n$/, "");
  const hashed = spawnSync("git", ["hash-object", "--stdin-paths"], { cwd: top, encoding: "utf8", input: paths.map(path => `${prefix}${path}\n`).join("") });
  if (hashed.status !== 0) throw new Error("Plugin source Git identity unavailable");
  const oids = hashed.stdout.split("\n").filter(Boolean);
  if (oids.length !== paths.length || paths.some((path, index) => tree.get(path.normalize("NFC")) !== oids[index])) throw new Error("Source review input differs from the reviewed commit");
}

/**
 * v2 cross-repository binding. Verifies the plugin repository state and the complete public review input, and
 * returns the extra keys the independent report's SOURCE_REVIEW_SCOPE must approve. `sourceRepository` is only
 * format-checked here (a local remote is not evidence); the controlled release entry compares it with its own repository.
 */
function bindingScope(evidence: SourceReviewEvidence, manifest: Record<string, unknown>, appDirectory: string, reviewRoot: string, actual: Record<string, string>) {
  const sourceFilesSha256 = sourceReviewInputsDigest(actual);
  const binding = evidence.binding;
  if (!exactKeys(binding, ["sourceRepository", "sourceCommit", "reviewInputs", "toolchainReceiptSha256"])
    || !exactKeys(binding!.reviewInputs, ["path", "sha256"])) throw new Error("Source review binding is invalid");
  const { sourceRepository, sourceCommit, reviewInputs, toolchainReceiptSha256 } = binding!;
  if (typeof sourceRepository !== "string" || !REPOSITORY.test(sourceRepository)) throw new Error("Source review repository is invalid");
  if (typeof sourceCommit !== "string" || !COMMIT.test(sourceCommit)) throw new Error("Source review commit is invalid");
  if (!validDigest(toolchainReceiptSha256) || typeof reviewInputs.path !== "string" || !validDigest(reviewInputs.sha256)) throw new Error("Source review binding digest is invalid");
  const app = realpathSync(resolve(appDirectory));
  if (git(app, ["rev-parse", "HEAD"]).trim() !== sourceCommit) throw new Error("Plugin source HEAD differs from the reviewed commit");
  if (git(app, ["status", "--porcelain=v1", "--untracked-files=all", "--", "."]).trim() !== "") throw new Error("Plugin source has changes outside the reviewed commit");
  assertInputsAreCommitted(app, sourceCommit, actual);
  const bytes = readFileSync(rootedFile(reviewRoot, reviewInputs.path, "Review input", "review root"));
  if (digest(bytes) !== reviewInputs.sha256) throw new Error("Review input digest differs");
  const calculation = JSON.parse(bytes.toString("utf8"));
  const toolchain = calculation?.toolchain, source = toolchain?.toolchainSource;
  if (calculation?.schemaVersion !== 1 || calculation.purpose !== "unapproved-source-review-bytes"
    || ["appId", "publisherId", "oauthAppId", "version"].some(field => typeof calculation.identity?.[field] !== "string" || calculation.identity[field] !== manifest[field])
    || calculation.sourceFilesSha256 !== sourceFilesSha256 || calculation.archiveSha256 !== evidence.expectedPackageSha256
    || !toolchain || typeof toolchain !== "object" || toolchain.gitHead !== sourceCommit || calculation.toolchainSha256 !== digest(JSON.stringify(toolchain))
    || source?.kind !== "receipt-content-consistent" || source.receiptSha256 !== toolchainReceiptSha256) throw new Error("Review input does not match the reviewed source, commit, toolchain receipt and package");
  return { sourceRepository, sourceCommit, reviewInputsSha256: reviewInputs.sha256, toolchainReceiptSha256 };
}

/** Returns a validation finding; invalid evidence never removes any denial. */
export function sourceReviewEvidenceFindings(manifest: Record<string, unknown>, evidence: SourceReviewEvidence, appDirectory?: string): Finding[] {
  try {
    const reviewRoot = evidence && typeof evidence === "object" ? sourceReviewRoot(evidence) : undefined;
    // Without an explicit review root only v1 evidence exists (unchanged); with one, only v2.
    if (!appDirectory || !evidence || typeof evidence !== "object" || evidence.schemaVersion !== (reviewRoot === undefined ? 1 : 2)
      || evidence.purpose !== "submission-source-review") throw new Error("Explicit source review evidence and app directory are required");
    for (const field of ["appId", "publisherId", "oauthAppId", "version"] as const) {
      if (typeof evidence[field] !== "string" || !evidence[field] || evidence[field] !== manifest[field]) throw new Error(`Source review identity differs: ${field}`);
    }
    if (!validDigest(evidence.expectedPackageSha256)) throw new Error("Source review package digest is invalid");
    const caps = evidence.reviewedHostCapabilities;
    if (!Array.isArray(caps) || caps.length === 0 || caps.some(cap => typeof cap !== "string" || !cap)
      || new Set(caps).size !== caps.length) throw new Error("Source review capability scope is invalid");
    const declared = new Set(((manifest.requires as { hostCapabilities?: string[] } | undefined)?.hostCapabilities ?? []));
    for (const component of ((manifest.runtime as { components?: { activation?: string }[] } | undefined)?.components ?? [])) {
      if (component.activation) declared.add(`activation.${component.activation}@1`);
    }
    if (caps.some(cap => !declared.has(cap))) throw new Error("Source review includes an undeclared capability");
    if (!evidence.sourceFiles || typeof evidence.sourceFiles !== "object" || Array.isArray(evidence.sourceFiles)
      || Object.entries(evidence.sourceFiles).some(([path, hash]) => !isSafePackagePath(path) || !validDigest(hash))) throw new Error("Source review input inventory is invalid");
    if (JSON.stringify(JSON.parse(readFileSync(safeChild(resolve(appDirectory), "app.manifest.json"), "utf8"))) !== JSON.stringify(manifest)) throw new Error("Source review manifest differs from build input");
    const actual = collectSourceReviewInputs(appDirectory);
    if (JSON.stringify(actual) !== JSON.stringify(orderedFiles(evidence.sourceFiles))) throw new Error("Source review build inputs differ or are not completely covered");
    const scope = { purpose: evidence.purpose, appId: evidence.appId, publisherId: evidence.publisherId,
      oauthAppId: evidence.oauthAppId, version: evidence.version, reviewedHostCapabilities: [...caps].sort(),
      sourceFilesSha256: sourceReviewInputsDigest(actual), expectedPackageSha256: evidence.expectedPackageSha256, decision: "approved",
      ...(reviewRoot === undefined ? {} : bindingScope(evidence, manifest, appDirectory, reviewRoot, actual)) };
    if (!Array.isArray(evidence.reviewReports) || evidence.reviewReports.length === 0) throw new Error("Independent source review reports are required");
    let reviewedScope = false;
    const paths = new Set<string>();
    for (const report of evidence.reviewReports) {
      if (!report || typeof report.path !== "string" || !validDigest(report.sha256)) throw new Error("Source review report reference is invalid");
      const path = reportPath(appDirectory, report.path, reviewRoot);
      if (paths.has(path)) throw new Error("Duplicate source review report");
      paths.add(path);
      const bytes = readFileSync(path);
      if (digest(bytes) !== report.sha256) throw new Error("Source review report digest differs");
      for (const match of bytes.toString("utf8").matchAll(/^SOURCE_REVIEW_SCOPE=(\{[^\r\n]*\})\r?$/gm)) {
        const reviewed = JSON.parse(match[1]!);
        if (Array.isArray(reviewed.reviewedHostCapabilities)) reviewed.reviewedHostCapabilities.sort();
        if (Object.keys(scope).every(key => JSON.stringify(reviewed[key]) === JSON.stringify(scope[key as keyof typeof scope]))) reviewedScope = true;
      }
    }
    if (!reviewedScope) throw new Error("Independent report does not approve this exact source scope and package digest");
    return [];
  } catch (cause) {
    const root = evidence && typeof evidence === "object" ? sourceReviewRoot(evidence) : undefined;
    return [{ code: "MANIFEST_REFERENCE_INVALID", pointer: "sourceReview", detail: root === undefined
      ? (cause instanceof Error ? cause.message : "Invalid source review evidence") : reviewRootError(cause, root) }];
  }
}

export function assertSourceReviewArchive(evidence: SourceReviewEvidence | undefined, archive: Uint8Array): void {
  if (evidence && digest(archive) !== evidence.expectedPackageSha256) throw new Error("Source review expected package digest differs from actual archive");
}
