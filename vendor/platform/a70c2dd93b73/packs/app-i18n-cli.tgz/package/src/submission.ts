/**
 * Local Open Platform submission gate. No upload, review, charge or publish operations.
 * Package entry: `reai-app-i18n submission check|pack …` (see ./submission-cli).
 */
import { createHash } from "node:crypto";
import { closeSync, existsSync, lstatSync, openSync, statSync, mkdirSync, mkdtempSync, readFileSync, realpathSync, rmSync, writeFileSync } from "node:fs";
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { packApp, packedFiles, parseCompression, verifyPackagedResources, validateManifest, validateLocaleBytes, readSourceReviewEvidence, type SourceReviewEvidence, type PackOptions } from "./index";

export interface SubmissionIdentity {
  schemaVersion: 1;
  version: string;
  appId: string;
  publisherId: string;
  oauthAppId: string;
  productId: string;
  target: "universal";
}
const identityKeys = ["schemaVersion", "version", "appId", "publisherId", "oauthAppId", "productId", "target"];
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
// The platform freeze compares Manifest publisherId with product.publisher_id, which is either the
// owning Team UUID or the exact reserved official identity "reai" (2026-09-17 Terminal product card:
// "Source: the existing reserved platform identity reai. Use the value above in your package manifest.";
// server annotates the same value as official_reserved). Anything else is drift, not a publishable publisher.
const reservedPublisherId = "reai";
// Open Platform submission contract (2026-09-14).
const submissionVersion = /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?$/;
const sha256 = (bytes: Uint8Array) => createHash("sha256").update(bytes).digest("hex");
const fail = (message: string): never => { throw new Error(`SUBMISSION_PREFLIGHT: ${message}`); };
// The Open Platform validates uploaded packages against its own Manifest contract baseline, whose
// i18n messages[].target enum predates the metadata.i18n@2 targets (storeListing.*, permission.purpose,
// requirement.displayName). 2026-09-26 Codex Link 0.5.11 was rejected after upload with
// "/i18n/messages/9/target · enum · 1.1@c3475cb"; Voice (b220b130) and Browser (e142e1ab) had already
// dropped to metadata.i18n@1 for the same reason. The 1.1@31cf8889 baseline deployed 2026-09-27 keeps the
// same 11-target enum (metadata.i18n@2 was not synced). Reject locally before packing. The enum is tied to the
// baseline: if a future contract changes it, move it into ServerContract instead of keeping one global list.
export const SERVER_I18N_TARGETS = [
  "name", "description", "sidebar.label", "surface.title", "command.title", "command.bindingPickerTitle",
  "titlebarAction.label", "titlebarAction.text", "titlebarStatus.label", "scheduledTask.title", "scheduledTask.description",
] as const;

// Backend contract beyond i18n. Deployed since 2026-09-27 on both production nodes; the 2026-10-02 rollout
// added agentFeatures without metadata.i18n@2.
// - upload/freeze now validates REAIAPP_MANIFEST_SCHEMA_BASELINE = "1.1@005a0f63-agent-features"
//   (backend package validator); requirements[].probe.id enum = the four v1 probes plus
//   codex-app-server-v2 / pi-agent-v2 / dsh-native-v2, anything else → 400 reaiapp_manifest_schema_invalid;
// - reviewers can only approve capabilities in the backend capability-review catalog (25 items,
//   "Driver host-support-matrix hostApi 1.21.0"); anything else is
//   app_capability_approval_invalid at approval, and a Host grant-gated capability without a platform approval is
//   refused by the Host.
// The previous baseline 1.1@c3475cb (v1 probes only, 22 reviewable capabilities) is removed rather than kept as an
// option: no deployed node enforces it any more and the new contract only adds enum values, so checking against it
// could only reproduce rejections the backend no longer issues. The next in-flight backend change goes in as an
// opt-in `pending-rollout` entry and replaces `current` once it is deployed.
const PROBE_IDS_1_1_31CF8889 = [
  "codex-app-server-v1", "pi-agent-v1", "dsh-runner-v1", "audio8-helper-v1",
  "codex-app-server-v2", "pi-agent-v2", "dsh-native-v2",
] as const;
const REVIEWABLE_CAPABILITIES_HOST_1_21 = [
  "agent.codex@1", "agent.codex.tasks@1", "agent.local@1", "agent.dsh@1", "agent.session@1", "agent.session@2",
  "agent.pi-management@1", "agent.dsh-observe@1", "activation.startup@1", "voice.input@1", "voice.command@1",
  "voice.recordings@1", "voice.deliver@1", "voice.context@1", "cloud.model.invoke@1", "cloud.workflow.invoke@1",
  "system.folder-pick@1", "local.files@1", "browser.engine@1", "computer.engine@1", "tts.local@1",
  "developer.platform@1", "terminal.session@1", "surface.clipboard@1", "local.terminal.exec@1",
] as const;
// Vendored 1.1@31cf8889 contributes.additionalProperties=false. Local Host schema is newer:
// agentFeatures was absent on the 2026-10-02 production server (Voice rc3 freeze failure); keep this historical snapshot.
const CONTRIBUTES_PROPERTIES_1_1_31CF8889 = [
  "surfaces", "services", "titlebarActions", "titlebarStatus", "tabItems", "actionItems",
  "eventSubscriptions", "acceptsActionContext", "sidebarItems", "scheduledTasks", "commands",
  "intents", "recommendedBindings",
] as const;
export interface ServerContract {
  name: string;
  baseline: string;
  backend: "deployed" | "pending-rollout" | "historical";
  probeIds: readonly string[];
  reviewableCapabilities: readonly string[];
  contributesProperties: readonly string[];
}
// 2026-10-15 后端上线：
// REAIAPP_MANIFEST_SCHEMA_BASELINE = "1.1@005a0f63-notification-scenes"（contributes 放行 notificationScenes），
// 可审核能力扩到 29 项（新增 audio.capture@1 / audio.clips@1 / surface.escape@1 / resources.files@1）。
// 原 notification-scenes-pending / v105-capabilities-pending 合入 current 并退役。
// tasks.present@1、notifications.publish@1 仍不在可批准表里，不加。
const REVIEWABLE_CAPABILITIES_HOST_1_25_V105 = [
  ...REVIEWABLE_CAPABILITIES_HOST_1_21, "audio.capture@1", "audio.clips@1", "surface.escape@1", "resources.files@1",
] as const;
export const SERVER_CONTRACTS = {
  current: {
    name: "current", baseline: "1.1@005a0f63-notification-scenes", backend: "deployed",
    probeIds: PROBE_IDS_1_1_31CF8889, reviewableCapabilities: REVIEWABLE_CAPABILITIES_HOST_1_25_V105,
    contributesProperties: [...CONTRIBUTES_PROPERTIES_1_1_31CF8889, "agentFeatures", "notificationScenes"],
  },
  "legacy-31cf8889": {
    name: "legacy-31cf8889", baseline: "1.1@31cf8889", backend: "historical",
    probeIds: PROBE_IDS_1_1_31CF8889, reviewableCapabilities: REVIEWABLE_CAPABILITIES_HOST_1_21,
    contributesProperties: CONTRIBUTES_PROPERTIES_1_1_31CF8889,
  },
} as const satisfies Record<string, ServerContract>;
export type ServerContractName = keyof typeof SERVER_CONTRACTS;
/** Contract names that used to be accepted; old command lines fail with the reason instead of a bare "unknown". */
const RETIRED_SERVER_CONTRACTS: Readonly<Record<string, string>> = {
  "notification-scenes-pending": "its baseline 1.1@005a0f63-notification-scenes was deployed on 2026-10-15 (backend rollout) and is now current; drop --server-contract",
  "v105-capabilities-pending": "its four reviewable capabilities were deployed on 2026-10-15 (backend rollout) and are now in current; drop --server-contract",
  "agent-features-pending": "its baseline 1.1@005a0f63-agent-features was deployed on 2026-10-02 and is now current; drop --server-contract",
  "native-v2-pending": "its baseline 1.1@31cf8889 was deployed on 2026-09-27 is included in the current contract; drop --server-contract",
};
const DEFAULT_SERVER_CONTRACT: ServerContract = SERVER_CONTRACTS.current;
export function serverContract(name: string): ServerContract {
  if (Object.hasOwn(RETIRED_SERVER_CONTRACTS, name)) fail(`--server-contract ${JSON.stringify(name)} is retired: ${RETIRED_SERVER_CONTRACTS[name]}`);
  // 不复述输入：参数解析发生在读身份之前，误填的受保护 ID 此时还无法脱敏。
  if (!Object.hasOwn(SERVER_CONTRACTS, name)) fail(`unknown --server-contract; expected one of ${Object.keys(SERVER_CONTRACTS).join(", ")}`);
  return SERVER_CONTRACTS[name as ServerContractName];
}
/** Capabilities the Host only grants with a platform approval (Driver host-support-matrix grantGated). */
export const HOST_GRANT_GATED: ReadonlySet<string> = new Set(
  JSON.parse(readFileSync(fileURLToPath(import.meta.resolve("@reai/app-contract/host-support-matrix.json")), "utf8")).hostCapabilities.grantGated,
);

export function verifyServerI18nTargets(manifest: Record<string, unknown>, contract: ServerContract = DEFAULT_SERVER_CONTRACT) {
  const declaration = manifest.i18n;
  if (!declaration || typeof declaration !== "object") return;
  const messages = (declaration as { messages?: unknown }).messages;
  if (!Array.isArray(messages)) return;
  const accepted = new Set<string>(SERVER_I18N_TARGETS);
  messages.forEach((message, index) => {
    const target = message && typeof message === "object" ? (message as { target?: unknown }).target : undefined;
    if (typeof target === "string" && !accepted.has(target))
      fail(`/i18n/messages/${index}/target ${JSON.stringify(target)} is not in the Open Platform manifest contract enum (${contract.baseline}); drop metadata.i18n@2 targets (storeListing.* etc.) and declare metadata.i18n@1 — store listing text is entered in the submission form`);
  });
}

/** Lists vendored field, probe and capability differences in one failure; local full schema checks remain mandatory. */
export function verifyServerContract(manifest: Record<string, unknown>, contract: ServerContract = DEFAULT_SERVER_CONTRACT) {
  const findings: string[] = [];
  const contributes = manifest.contributes && typeof manifest.contributes === "object" && !Array.isArray(manifest.contributes)
    ? manifest.contributes as Record<string, unknown> : {};
  for (const property of Object.keys(contributes)) {
    if (!contract.contributesProperties.includes(property)) {
      const pointer = property.replace(/~/g, "~0").replace(/\//g, "~1");
      findings.push(`/contributes/${pointer} ${JSON.stringify(property)} is not in the vendored schema properties (additionalProperties=false) → upload rejected as reaiapp_manifest_schema_invalid`);
    }
  }
  const requirements = Array.isArray(manifest.requirements) ? manifest.requirements : [];
  requirements.forEach((requirement, index) => {
    const probe = requirement && typeof requirement === "object" ? (requirement as { probe?: unknown }).probe : undefined;
    const id = probe && typeof probe === "object" ? (probe as { id?: unknown }).id : undefined;
    if (typeof id === "string" && !contract.probeIds.includes(id))
      findings.push(`/requirements/${index}/probe/id ${JSON.stringify(id)} is not in the backend schema enum → upload rejected as reaiapp_manifest_schema_invalid`);
  });
  const requires = manifest.requires && typeof manifest.requires === "object" ? manifest.requires as { hostCapabilities?: unknown } : {};
  const capabilities = Array.isArray(requires.hostCapabilities) ? requires.hostCapabilities : [];
  for (const capability of capabilities)
    if (typeof capability === "string" && HOST_GRANT_GATED.has(capability) && !contract.reviewableCapabilities.includes(capability))
      findings.push(`requires.hostCapabilities ${JSON.stringify(capability)} is Host grant-gated but reviewers cannot approve it (app_capability_approval_invalid), so the Host would refuse it`);
  if (findings.length)
    fail(`Open Platform backend contract ${contract.name} (${contract.baseline}, ${contract.backend}) rejects:\n  - ${findings.join("\n  - ")}`);
}

export function readIdentity(value: unknown): SubmissionIdentity {
  if (!value || typeof value !== "object" || Array.isArray(value)) fail("submission.identity.json must be an object");
  const data = value as Record<string, unknown>;
  if (Object.keys(data).length !== identityKeys.length || identityKeys.some(key => !Object.hasOwn(data, key)))
    fail("submission.identity.json requires exactly schemaVersion, version, appId, publisherId, oauthAppId, productId and target; never store secrets here");
  if (typeof data.version !== "string" || !data.version || data.version.trim() !== data.version) fail("submission version must be explicitly recorded without surrounding whitespace");
  if (!submissionVersion.test(data.version as string)) fail("version must match the Open Platform submission SemVer format");
  if (data.schemaVersion !== 1 || data.target !== "universal") fail("submission target must be universal (not Manifest targets)");
  if (typeof data.appId !== "string" || !/^[a-z0-9][a-z0-9-]*(\.[a-z0-9][a-z0-9-]*)+$/.test(data.appId)) fail("appId must be the existing reverse-domain plugin ID");
  if (typeof data.publisherId !== "string" || !(uuid.test(data.publisherId) || data.publisherId === reservedPublisherId))
    fail("publisherId must be the current Product Team UUID or the reserved platform identity reai");
  if (typeof data.productId !== "string" || !uuid.test(data.productId)) fail("productId must be the current Product UUID");
  if (typeof data.oauthAppId !== "string" || !/^[A-Za-z0-9._-]{8,128}$/.test(data.oauthAppId)) fail("oauthAppId must be the current OAuth Client ID");
  return data as unknown as SubmissionIdentity;
}

export function verifyIdentity(manifest: Record<string, unknown>, identity: SubmissionIdentity, version?: string, contract: ServerContract = DEFAULT_SERVER_CONTRACT, evidence?: SourceReviewEvidence, sourceRoot?: string) {
  for (const key of ["appId", "publisherId", "oauthAppId"] as const)
    if (manifest[key] !== identity[key]) fail(`Manifest ${key} is missing or differs from submission.identity.json`);
  if ("productId" in manifest || "clientId" in manifest) fail("productId belongs to submission identity; OAuth Client ID belongs to oauthAppId");
  if (manifest.version !== identity.version) fail(`submission version ${identity.version} differs from Manifest version ${String(manifest.version)}`);
  if (version !== undefined && manifest.version !== version) fail("package.json and Manifest version differ");
  const findings = validateManifest(manifest, evidence, sourceRoot);
  if (findings.length) fail(JSON.stringify(findings));
  verifyServerI18nTargets(manifest, contract);
  verifyServerContract(manifest, contract);
}

/** The form value is an explicit input; a local build cannot observe a remote draft. */
export function verifyFormVersion(identity: SubmissionIdentity, formVersion: string) {
  if (formVersion !== identity.version)
    fail(`form version ${JSON.stringify(formVersion)} differs from package/submission version ${identity.version}; correct the form or deliberately rebuild the intended release version`);
}

export function verifyIcon(path: unknown, bytes: Uint8Array | undefined) {
  if (typeof path !== "string" || !path.endsWith(".png") || !bytes) return fail("Manifest icon must reference a packaged PNG");
  const png = Buffer.from(bytes);
  if (png.length < 33 || png.length > 256 * 1024 || png.subarray(0, 8).toString("hex") !== "89504e470d0a1a0a" || png.toString("ascii", 12, 16) !== "IHDR")
    fail("icon must be a PNG no larger than 256 KiB");
  const width = png.readUInt32BE(16), height = png.readUInt32BE(20);
  if (width < 1 || height < 1 || width > 512 || height > 512) fail("icon dimensions must be between 1 and 512 pixels");
}

/** Legacy default location. An explicit `--identity` file outside the source tree replaces it. */
export const IN_TREE_IDENTITY = "submission.identity.json";

/** Fixed messages only: a malformed identity file must never be echoed into logs. */
export function loadIdentity(path: string): SubmissionIdentity {
  let value: unknown;
  try { value = JSON.parse(readFileSync(path, "utf8")); }
  catch { return fail("submission identity file is missing, unreadable or not valid JSON"); }
  return readIdentity(value);
}

export function verifySource(root: string, contract: ServerContract = DEFAULT_SERVER_CONTRACT, evidence?: SourceReviewEvidence, identityPath = join(root, IN_TREE_IDENTITY)) {
  const identity = loadIdentity(identityPath);
  const manifest = JSON.parse(readFileSync(join(root, "app.manifest.json"), "utf8"));
  const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
  if (typeof pkg.version !== "string") fail("package.json version is required");
  verifyIdentity(manifest, identity, pkg.version, contract, evidence, root);
  const icon = typeof manifest.icon === "string" && !manifest.icon.startsWith("/") && !manifest.icon.split("/").includes("..") ? manifest.icon : fail("invalid icon resource path");
  if (!existsSync(join(root, icon))) fail("Manifest icon resource is missing");
  verifyIcon(icon, readFileSync(join(root, icon)));
  return { identity, manifest };
}

export function verifyArchive(bytes: Buffer, identity: SubmissionIdentity, version: string, contract: ServerContract = DEFAULT_SERVER_CONTRACT, evidence?: SourceReviewEvidence, sourceRoot?: string) {
  if (!bytes.length || bytes.length > 64 * 1024 * 1024) fail("archive size must be between 1 byte and 64 MiB");
  const files = packedFiles(bytes);
  const manifest = verifyPackagedResources(files);
  verifyIdentity(manifest, identity, version, contract, evidence, sourceRoot);
  if (evidence && sha256(bytes) !== evidence.expectedPackageSha256) fail("source-review expected package digest mismatch");
  verifyIcon(manifest.icon, files.get(String(manifest.icon)));
  const findings = validateLocaleBytes(manifest, files, true);
  if (findings.length) fail(JSON.stringify(findings));
  return { manifest, sha256: sha256(bytes), sizeBytes: bytes.length, entries: files.size };
}

/** Also guard concurrent invocations after the initial existence check. Returns true only when this call created the file. */
export function writeNewOrIdentical(path: string, bytes: Buffer): boolean {
  try { writeFileSync(path, bytes, { flag: "wx" }); return true; }
  catch (error) {
    if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
    if (!readFileSync(path).equals(bytes)) fail(`different output already exists: ${basename(path)}; use a new filename`);
    return false;
  }
}

/** Only the deployed current contract yields plain passed; historical checks reproduce old failures. */
export function preflightStatus(contract: ServerContract) {
  if (contract.backend === "historical") return "local-preflight-passed-historical-server-contract";
  return contract.backend === "deployed" ? "local-preflight-passed" : "local-preflight-passed-pending-backend-contract";
}
const contractReceipt = (contract: ServerContract) => ({ name: contract.name, baseline: contract.baseline, backend: contract.backend });

const formVersionCheck = (formVersion?: string) => formVersion === undefined ? "not-provided" : "matched-explicit-input";
const reviewReceipt = (evidence?: SourceReviewEvidence) => evidence
  ? { purpose: evidence.purpose, sha256: sha256(Buffer.from(JSON.stringify(evidence))), runtimeGrant: false, platformApproval: false } : null;
const SOURCE_CHECKS = ["identity", "manifest-schema", "server-contract", "source-png-icon"];

export interface SubmissionOptions extends PackOptions {
  /** Defaults to `<root>/submission.identity.json`. */
  identityPath?: string | undefined;
  /** Private file for the full identity receipt. pack defaults to `<out>.submission.json`. */
  receiptPath?: string | undefined;
  formVersion?: string | undefined;
  /** Re-validates the pre-flight path layout immediately before the final writes (narrows rename races). */
  recheckPaths?: (() => void) | undefined;
}

/** Existing different bytes are never replaced; checked before any write. */
function assertWritable(path: string, bytes: Buffer) {
  if (existsSync(path) && !readFileSync(path).equals(bytes)) fail(`different output already exists: ${basename(path)}; use a new filename`);
}
const receiptBytes = (receipt: unknown) => Buffer.from(`${JSON.stringify(receipt, null, 2)}\n`);

export async function packSubmission(root: string, output: string, contract: ServerContract = DEFAULT_SERVER_CONTRACT, evidence?: SourceReviewEvidence, options: SubmissionOptions = {}) {
  const compression = parseCompression(options.compression);
  const { identity, manifest } = verifySource(root, contract, evidence, options.identityPath);
  if (options.formVersion !== undefined) verifyFormVersion(identity, options.formVersion);
  if (!output.endsWith(".reaiapp")) fail("output must end in .reaiapp");
  const receiptPath = options.receiptPath ?? `${output}.submission.json`;
  mkdirSync(dirname(output), { recursive: true });
  mkdirSync(dirname(receiptPath), { recursive: true });
  const temp = mkdtempSync(join(dirname(output), ".plugin-submission-"));
  try {
    const first = join(temp, "first.reaiapp"), second = join(temp, "second.reaiapp");
    await packApp(root, first, true, evidence, { compression });
    await packApp(root, second, true, evidence, { compression });
    const bytes = readFileSync(first);
    if (!bytes.equals(readFileSync(second))) fail("two builds produced different package bytes");
    const checked = verifyArchive(bytes, identity, manifest.version, contract, evidence, root);
    const receipt = {
      status: preflightStatus(contract), remoteSubmission: "not-performed", command: "pack", serverContract: contractReceipt(contract),
      ...identity, version: manifest.version, packageFile: basename(output), formVersionCheck: formVersionCheck(options.formVersion),
      sourceReviewEvidence: reviewReceipt(evidence),
      sha256: checked.sha256, sizeBytes: checked.sizeBytes,
      ...(compression === "deflate" ? { compression } : {}),
      sourceManifestSha256: sha256(readFileSync(join(root, "app.manifest.json"))),
      checks: ["identity", "manifest-schema", "server-contract", ...(options.formVersion !== undefined ? ["form-version"] : []), "locale-resources", "packaged-png-icon", "resource-hashes", "two-identical-builds", ...(compression === "deflate" ? ["deterministic-deflate"] : [])],
      note: "Product ID is submission metadata, not a Manifest field. Upload requires a real CAS fileId and a fresh review quote."
        + (contract.backend === "deployed" ? "" : ` Checked against the pending backend contract ${contract.baseline}: do not upload until that backend rollout is deployed.`),
    };
    const receiptContent = receiptBytes(receipt);
    // Package and receipt are delivered as a pair. The exclusive lock keeps a concurrent run from relying on a
    // package that this run may still roll back; only a package this run created is removed on receipt failure.
    const lockPath = `${output}.submission.lock`;
    let lock: number;
    try { lock = openSync(lockPath, "wx", 0o600); }
    catch { return fail(`another submission is writing ${basename(output)}; retry later (remove ${basename(lockPath)} if no run is active)`); }
    try {
      options.recheckPaths?.();
      for (const [path, content] of [[output, bytes], [receiptPath, receiptContent]] as const) assertWritable(path, content);
      const created = writeNewOrIdentical(output, bytes);
      try { writeNewOrIdentical(receiptPath, receiptContent); }
      catch (error) { if (created) rmSync(output, { force: true }); throw error; }
      return receipt;
    } finally { closeSync(lock); rmSync(lockPath, { force: true }); }
  } finally { rmSync(temp, { recursive: true, force: true }); }
}

/** Source-only or final-package check. The receipt states exactly which checks ran; check never claims two builds. */
export function checkSubmission(root: string, contract: ServerContract = DEFAULT_SERVER_CONTRACT, evidence?: SourceReviewEvidence, options: Omit<SubmissionOptions, "compression"> & { packagePath?: string | undefined } = {}) {
  const { identity, manifest } = verifySource(root, contract, evidence, options.identityPath);
  if (options.formVersion !== undefined) verifyFormVersion(identity, options.formVersion);
  const packed = options.packagePath ? verifyArchive(readFileSync(options.packagePath), identity, manifest.version, contract, evidence, root) : undefined;
  const receipt = {
    status: preflightStatus(contract), remoteSubmission: "not-performed", command: packed ? "check-package" : "check", serverContract: contractReceipt(contract),
    ...identity, formVersionCheck: formVersionCheck(options.formVersion), sourceReviewEvidence: reviewReceipt(evidence),
    ...(packed ? { packageFile: basename(options.packagePath!), sha256: packed.sha256, sizeBytes: packed.sizeBytes } : {}),
    checks: [...SOURCE_CHECKS, ...(options.formVersion !== undefined ? ["form-version"] : []), ...(packed ? ["final-package", "locale-resources", "packaged-png-icon", "resource-hashes"] : [])],
  };
  if (options.receiptPath) {
    const content = receiptBytes(receipt);
    options.recheckPaths?.();
    assertWritable(options.receiptPath, content); writeNewOrIdentical(options.receiptPath, content);
  }
  return receipt;
}

/** Physical path of a target that may not exist yet. Any existing component that is a symlink is rejected. */
function physicalTarget(path: string, label: string): string {
  let existing = resolve(path);
  const missing: string[] = [];
  while (!lstatSync(existing, { throwIfNoEntry: false })) {
    const parent = dirname(existing);
    if (parent === existing) break;
    missing.unshift(basename(existing)); existing = parent;
  }
  for (let cursor = existing; ; cursor = dirname(cursor)) {
    if (lstatSync(cursor).isSymbolicLink()) fail(`${label} path contains a symlink; pass the physical path (realpath)`);
    if (dirname(cursor) === cursor) break;
  }
  // native realpath returns the on-disk spelling, so case-insensitive volumes cannot alias the source tree.
  return join(realpathSync.native(existing), ...missing);
}
// The not-yet-existing tail keeps caller spelling; compare case-folded so that a case-insensitive
// volume cannot alias paths (conservative on case-sensitive volumes, where it only rejects more).
const folded = (path: string) => path.toLowerCase();
const inside = (root: string, target: string) => {
  const path = relative(folded(root), folded(target));
  return path === "" || !(path === ".." || path.startsWith(`..${sep}`) || isAbsolute(path));
};

export interface SubmissionPaths { identityPath: string; output?: string | undefined; receiptPath?: string | undefined; external: boolean }
/**
 * Runs before any mkdir, temp file or build. Without --identity / --receipt the legacy layout is unchanged.
 * With --identity the identity, receipt and package all live outside the source tree, so the source-review
 * inputs of a public tree (no identity file) and of a private submission are identical.
 */
export function resolveSubmissionPaths(root: string, options: { identity?: string | undefined; output?: string | undefined; receipt?: string | undefined } = {}): SubmissionPaths {
  const external = options.identity !== undefined, strict = external || options.receipt !== undefined;
  if (!strict) return { identityPath: join(root, IN_TREE_IDENTITY), output: options.output && resolve(options.output), receiptPath: undefined, external };
  const source = realpathSync.native(root);
  let identityPath = join(root, IN_TREE_IDENTITY);
  if (external) {
    identityPath = physicalTarget(options.identity!, "--identity");
    if (!lstatSync(identityPath, { throwIfNoEntry: false })?.isFile()) fail("--identity must be an existing regular file");
    // A hard link inside the plugin would put the same bytes into the source-review inputs and the package.
    if (statSync(identityPath).nlink !== 1) fail("--identity must not be hard-linked");
    if (inside(source, identityPath)) fail("--identity must be outside the plugin source tree");
    if (lstatSync(join(source, IN_TREE_IDENTITY), { throwIfNoEntry: false }))
      fail(`--identity cannot be combined with an in-tree ${IN_TREE_IDENTITY}; keep exactly one identity source`);
  }
  const output = options.output === undefined ? undefined : physicalTarget(options.output, "--out");
  // pack writes the default `<out>.submission.json` when --receipt is omitted; it gets the same checks.
  const receiptPath = options.receipt !== undefined ? physicalTarget(options.receipt, "--receipt")
    : output === undefined ? undefined : physicalTarget(`${output}.submission.json`, "receipt");
  if (external) for (const [label, path] of [["--out", output], ["--receipt", receiptPath]] as const)
    if (path && inside(source, path)) fail(`${label} must be outside the plugin source tree when --identity is used`);
  const taken = [identityPath, output, receiptPath].filter((path): path is string => Boolean(path));
  // Equal paths, or one nested under another, cannot hold both files (case-folded, see above).
  for (const [index, path] of taken.entries())
    for (const other of taken.slice(index + 1))
      if (inside(path, other) || inside(other, path)) fail("identity, package and receipt must be three separate files, none inside another");
  return { identityPath, output, receiptPath, external };
}

/** Logs carry status, version and digests only. The reserved public publisher "reai" is not a protected value. */
export function redactIdentity(text: string, identity?: Pick<SubmissionIdentity, "publisherId" | "oauthAppId" | "productId">) {
  if (!identity) return text;
  let result = text;
  for (const field of ["publisherId", "oauthAppId", "productId"] as const) {
    const value = identity[field];
    if (value && !(field === "publisherId" && value === reservedPublisherId)) result = result.replaceAll(value, `<redacted:${field}>`);
  }
  return result;
}
const SUMMARY_FIELDS = ["status", "remoteSubmission", "command", "serverContract", "appId", "version", "formVersionCheck", "packageFile", "sha256", "sizeBytes", "compression"] as const;
export function submissionSummary(receipt: Record<string, unknown>, receiptPath?: string) {
  const summary: Record<string, unknown> = {};
  for (const field of SUMMARY_FIELDS) if (receipt[field] !== undefined) summary[field] = receipt[field];
  if (receiptPath) summary.receiptFile = basename(receiptPath);
  return summary;
}

/** Shown in usage errors; the repository wrapper keeps its historic command name. */
export const DEFAULT_SUBMISSION_PROGRAM = "reai-app-i18n submission";
export function parseSubmissionArgs(args: string[], program = DEFAULT_SUBMISSION_PROGRAM) {
  const [command = "", directory = "", ...options] = args;
  const usage = `usage: ${program} check <pluginDir> [--package file.reaiapp] [--form-version version] [--server-contract name] [--source-review file.json [--review-root dir]] [--identity file.json] [--receipt file.json] | pack <pluginDir> --out file.reaiapp [--form-version version] [--server-contract name] [--source-review file.json [--review-root dir]] [--compression store|deflate] [--identity file.json] [--receipt file.json]`;
  if (!directory || !["check", "pack"].includes(command) || options.length % 2) fail(usage);
  const parsed = new Map<string, string>();
  for (let index = 0; index < options.length; index += 2) {
    const key = options[index] ?? "", value = options[index + 1] ?? "";
    if (!["--form-version", "--server-contract", "--source-review", "--review-root", "--identity", "--receipt", ...(command === "pack" ? ["--out", "--compression"] : ["--package"])].includes(key) || !value || value.startsWith("--") || parsed.has(key)) fail(usage);
    parsed.set(key, value);
  }
  if (command === "pack" && !parsed.has("--out")) fail(usage);
  if (parsed.has("--review-root") && !parsed.has("--source-review")) fail(usage);
  const contract = serverContract(parsed.get("--server-contract") ?? DEFAULT_SERVER_CONTRACT.name);
  return { command: command as "check" | "pack", directory, target: parsed.get(command === "pack" ? "--out" : "--package"), formVersion: parsed.get("--form-version"), sourceReview: parsed.get("--source-review"), reviewRoot: parsed.get("--review-root"), identity: parsed.get("--identity"), receipt: parsed.get("--receipt"), contract, compression: parseCompression(parsed.get("--compression")) };
}

/** Order: structural parse → identity → every other check, so later errors can be redacted. */
export async function runSubmissionCli(argv: string[], write: { out(text: string): void; err(text: string): void } = { out: console.log, err: console.error }, program = DEFAULT_SUBMISSION_PROGRAM): Promise<number> {
  let identity: SubmissionIdentity | undefined;
  // Review-root mode: the private root never appears in output, including native fs errors on paths inside it.
  let privateRoot: string | undefined;
  const shown = (text: string) => privateRoot ? text.replaceAll(privateRoot, "<review-root>") : text;
  try {
    const { command, directory, target, formVersion, sourceReview, reviewRoot, identity: identityFlag, receipt, contract, compression } = parseSubmissionArgs(argv, program);
    if (reviewRoot) privateRoot = resolve(reviewRoot);
    const root = resolve(directory);
    const flags = { identity: identityFlag, output: command === "pack" ? target : undefined, receipt };
    let paths: SubmissionPaths;
    try {
      paths = resolveSubmissionPaths(root, flags);
      identity = loadIdentity(paths.identityPath);
    } catch (error) {
      // Native fs errors embed full paths, which may contain protected values that cannot be redacted yet.
      if (error instanceof Error && error.message.startsWith("SUBMISSION_PREFLIGHT: ")) throw error;
      const code = (error as NodeJS.ErrnoException | undefined)?.code;
      return fail(`cannot access the plugin, identity, output or receipt path${typeof code === "string" && /^E[A-Z]+$/.test(code) ? ` (${code})` : ""}; nothing was written`);
    }
    const resolved = paths;
    const recheckPaths = () => {
      if (JSON.stringify(resolveSubmissionPaths(root, flags)) !== JSON.stringify(resolved)) fail("output, receipt or identity paths changed during the run; nothing more was written");
    };
    const evidence: SourceReviewEvidence | undefined = sourceReview ? readSourceReviewEvidence(resolve(sourceReview), { reviewRoot }) : undefined;
    const options = { identityPath: paths.identityPath, receiptPath: paths.receiptPath, formVersion, recheckPaths };
    const result = command === "pack"
      ? await packSubmission(root, paths.output!, contract, evidence, { ...options, compression })
      : checkSubmission(root, contract, evidence, { ...options, packagePath: target ? resolve(target) : undefined });
    const receiptPath = command === "pack" ? paths.receiptPath ?? `${paths.output}.submission.json` : paths.receiptPath;
    write.out(shown(redactIdentity(JSON.stringify(submissionSummary(result, receiptPath), null, 2), identity)));
    return 0;
  } catch (error) {
    write.err(shown(redactIdentity(error instanceof Error ? error.message : String(error), identity)));
    return 1;
  }
}
