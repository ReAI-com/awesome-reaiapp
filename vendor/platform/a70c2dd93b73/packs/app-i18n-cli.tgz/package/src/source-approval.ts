/** Source preflight only: package installation still verifies artifact identity in Host. */
import { readFileSync } from "node:fs";
import type { Finding } from "@reai/app-cli";

const readContract = (name: string) => JSON.parse(readFileSync(
  new URL(import.meta.resolve(`@reai/app-contract/${name}`)), "utf8"));
const policy = readContract("capability-review-policy.seed.json") as {
  approvals: { appId: string; publisherId: string; version: string;
    packageSha256: string | null; approvedHostCapabilities: string[] }[];
};
const matrix = readContract("host-support-matrix.json") as {
  hostCapabilities: { granted: string[]; grantGated: string[]; localDeveloperGrantable?: string[] };
  runtime: { activationAllowed?: string[]; activationGated?: string[] };
};
type Manifest = {
  appId: string; publisherId: string; version: string;
  requires?: { hostCapabilities?: string[] };
  runtime?: { components?: { activation?: string }[] };
};

/**
 * `localDev`：按侧载（开发者模式本地安装）口径校验——支持矩阵 `localDeveloperGrantable`
 * 白名单内的能力与商店同权、无需源码审核记录（issue #1444）。默认按商店口径，上架仍由
 * 平台审核决定。
 */
export function sourceApprovalFindings(manifest: Manifest, legacy: Finding[], localDev = false): Finding[] {
  // A platform package approval (bound to a digest) normally also covers later source
  // versions of the same publisher. An app already governed by per-version source review
  // (it has a digest-less record pinned to an exact version for this publisher) keeps
  // that discipline: its package approval covers only its own version, so every new
  // source version still needs its own review record.
  const perVersionReviewed = policy.approvals.some(approval =>
    approval.appId === manifest.appId && approval.publisherId === manifest.publisherId
    && approval.version !== "*" && approval.packageSha256 === null);
  const sideload = new Set(matrix.hostCapabilities.localDeveloperGrantable ?? []);
  const approved = (capability: string) => (localDev && sideload.has(capability)) || policy.approvals.some(approval =>
    approval.appId === manifest.appId
    && (approval.version === "*" || (approval.publisherId === manifest.publisherId
      && (approval.version === manifest.version
        || (typeof approval.packageSha256 === "string" && !perVersionReviewed))))
    && approval.approvedHostCapabilities.includes(capability));
  const checks = gatedSourceChecks(manifest);
  // Recompute both legacy denials and legacy appId-only successes. Do not erase
  // unrelated findings, unavailable capabilities, or schema errors.
  const pointers = new Set(checks.map(check => check.pointer));
  return [
    ...legacy.filter(finding => finding.code !== "APP_CAPABILITY_NOT_GRANTED" || !pointers.has(finding.pointer)),
    ...checks.filter(check => !approved(check.capability)).map(check => ({
      code: "APP_CAPABILITY_NOT_GRANTED" as const, pointer: check.pointer,
      detail: `${check.capability} requires an applicable source review approval`,
    })),
  ];
}

/** Same gated declarations for normal policy checks and non-authorizing byte calculation. */
export function gatedSourceChecks(manifest: Manifest): { pointer: string; capability: string }[] {
  const checks: { pointer: string; capability: string }[] = [];
  (manifest.requires?.hostCapabilities ?? []).forEach((capability, index) => {
    if (!matrix.hostCapabilities.granted.includes(capability)
      && matrix.hostCapabilities.grantGated.includes(capability)) {
      checks.push({ pointer: `requires.hostCapabilities[${index}]`, capability });
    }
  });
  (manifest.runtime?.components ?? []).forEach((component, index) => {
    const activation = component.activation ?? "";
    if (!(matrix.runtime.activationAllowed ?? []).includes(activation)
      && (matrix.runtime.activationGated ?? []).includes(activation)) {
      checks.push({ pointer: `runtime.components[${index}].activation`, capability: `activation.${activation}@1` });
    }
  });
  return checks;
}

/**
 * 默认（商店）口径下被拦的受控能力里，有哪些在侧载白名单内——命令行据此单独提示
 * 「本地开发安装可加 --local-dev」。错误详情本身保持稳定原文，供受控发布逐字比对。
 */
export function sideloadHintCapabilities(manifest: Manifest, findings: Finding[]): string[] {
  const sideload = new Set(matrix.hostCapabilities.localDeveloperGrantable ?? []);
  const denied = new Set(findings.filter(f => f.code === "APP_CAPABILITY_NOT_GRANTED").map(f => f.pointer));
  return gatedSourceChecks(manifest).filter(c => denied.has(c.pointer) && sideload.has(c.capability)).map(c => c.capability);
}
